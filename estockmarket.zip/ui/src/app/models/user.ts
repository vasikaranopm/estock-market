export class User {
    userId: string;
    userName: string;
    password: string;
    userMobile: Number;
    userAddedDate: Date;
    firstName: string;
    lastName: string;
    userRole: string;
    email: string
    isActive: number;
}
