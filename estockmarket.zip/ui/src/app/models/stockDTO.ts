export class StockDTO {
    companyCode: String;
    price: number;
    date?: Date;


}
