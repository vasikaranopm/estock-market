export class CompanyDTO {
    code: String;
    name: String;
    ceo: String;
    turnOver: number;
    website: String;
    stockExchange: String;




}
